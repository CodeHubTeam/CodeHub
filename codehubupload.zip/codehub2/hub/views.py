# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http import HttpResponseRedirect, Http404
from django.shortcuts import render, render_to_response
from . import models
from .models import User, project_user, Project
from django.shortcuts import get_object_or_404, render

#from mygit import *                 #去掉注释就使用了pygit2，没装pygit2请注释此行

codehub_path = '/Users/sxyzc/repo/'   #一般所有用户所在的目录，全局设置，迁移后自己修改

import os.path

# Create your views here.
def index(request):
    return render(request,'index.html')

def mainPage(request):
    return render(request,'mainPage.html')

def login(request):
    return render(request,'login.html')

def code_test(request):
    return render(request,'code.html')

#def code(request, project_owner, project_id):
#def code(request, project_ii):
def code(request, *args, **kwargs):
    #print args
    print (kwargs['project_name'])
    print (kwargs['project_owner'])
    #mycat_id = kwargs['pk']
    #print(project_ii)
    print ("22222222222")
    try:
        project = Project.objects.get(project_name=kwargs['project_name'], lead_user=kwargs['project_owner'])
        #project = Project.objects.get(project_id=res)
        request.session['now_project_id'] = project.project_id
        request.session['now_project_name'] = project.project_name
        request.session['now_project_owner'] = project.lead_user.user_name
        files = os.listdir(codehub_path + project.repo_path)
        print (files)
        print ('***************')
        print (codehub_path + project.repo_path)
    except Project.DoesNotExist:
        raise Http404("Project does not exist")
    return render(request, 'code.html', {'project': project,'files': files})

def branch(request):
    return render(request,'branch.html')

def register(request):
    return render(request,'register.html')

def processRegister(request):
    print ("注册中")
    name = request.POST.get('name')
    print (name)
    email = request.POST.get('email',"noemail")
    print (email)
    password = request.POST.get('password')
    print (password)
    rePassword = request.POST.get('rePassword','norepassword')
    print (rePassword)
    if email != "noemail":
        print (models.User.objects.create(user_name=name,mail=email,password=password))
        pro_list = []
        request.session['user_name'] = name
        pro_id_list = project_user.objects.filter(user_name=request.session['user_name'])
        for i, j in enumerate(pro_id_list):
            pro_list.append(Project.objects.get(pk=j.project_id))
        print (pro_list)
        print (request.session['user_name'])
        return render(request, 'projectCatalog.html', {'projects': pro_list})
    else:
        theuser = get_object_or_404(User, pk=name)
        # print(theuser)
        # print("---------------")
        pro_list = []
        if theuser.password != password:
            print ("wrong password")
        else:
            request.session['user_name'] = name
            pro_id_list = project_user.objects.filter(user_name=request.session['user_name'])
            for i, j in enumerate(pro_id_list):
                pro_list.append(Project.objects.get(pk=j.project_id))
            print (pro_list)
            print (request.session['user_name'])
        return render(request, 'projectCatalog.html', {'projects': pro_list})

"""
def proceLogin(request):
    print("----------")
    name = request.POST.get('name')
    password = request.POST.get('password')
    #theuser = User.objects.get(pk=name)
    theuser = get_object_or_404(User, pk=name)
    #print(theuser)
    #print("---------------")
    pro_list = []
    if theuser.password != password: print "wrong password"
    else:
        request.session['user_name'] = name
        pro_id_list = project_user.objects.filter(user_name=request.session['user_name'])
        for i, j in enumerate(pro_id_list):
        	pro_list.append(Project.objects.get(pk=j.project_id))
        print pro_list
        print request.session['user_name']
    return render(request, 'projectCatalog.html', {'projects': pro_list})
"""
def processCreate(request):
    return render(request, 'projectCreate.html')

def member(request):
#def member(request, *args, **kwargs):
    #print args

    print ('member!!!!!!!!!!!!!!!!!!!!')
    pro_id  = request.session['now_project_id']
    print ('member')

    input_member = request.POST.get('i_name', "ffff")
    #pro_id = 1
    print('pro_id', pro_id)
    print ('input_member', input_member)
    if len(input_member) == 0:
        pass
    else:
        ff = models.User.objects.filter(user_name=input_member)
        if len(ff) != 0:
            uu = models.User.objects.get(user_name=input_member)
            pp = models.project_user.objects.filter(user_name=input_member,project_id=pro_id)
            if len(pp) == 0:
                models.project_user.objects.create(project_id=pro_id, user_name=uu)
                print ('ok')
            else:
                print ('已存在')

    all_members = models.project_user.objects.filter(project_id=pro_id)
    print (len(all_members),"#########")
    return render(request, 'member.html', {"members": all_members})
def upload(request):
    if request.method == 'GET':
        return render_to_response('upload.html')
    elif request.method == 'POST':
        obj = request.FILES.get('fafafa')
        f = open(os.path.join('Codehub',obj.name),'wb')
        for line in obj.chunks():
            f.write(line)
        f.close()
        return render_to_response('upload.html')
# 	pro_id = 1
# 	all_members = models.project_user.objects.filter(project_id=pro_id)
# #return render(request, 'member.html', {"members": all_members})
#         return render(request, 'member.html')

"""
def proMem(request):
    print 'promem!!!!!!!!!!!!!!!!!!!!'
    input_member = request.POST.get('i_name', 1)
    pro_id = request.session['now_project_id']
    print('pro_id', pro_id)
    print ('input_member', input_member)
    if len(input_member) == 0:
        pass
    else:
        ff = models.User.objects.filter(user_name=input_member)
        if len(ff) != 0:
            uu = models.User.objects.get(user_name=input_member)
            pp = models.project_user.objects.filter(user_name=input_member)
            if len(pp) == 0:
                models.project_user.objects.create(project_id=pro_id, user_name=uu)
                print 'ok'
            else:
                print '已存在'
        #findup = models.Project.objects.get(project_id=pro_id)
        # allusers = models.User.objects.all().values_list('user_name')
        # print len(allusers)
        # print allusers
        # if 'user01' in allusers:
        #     print 'zai'
        # else:
        #     print 'buzai'
        #     models.project_user.objects.create(project_id=pro_id, user_name=input_member)

            #findup = models.Project.objects.get(project_id=pro_id)
        #print findup2
        # if findup2 is not null:
        #     pass
        # else:
        #     models.project_user.objects.create(project_id = pro_id, user_name = input_member)

    all_members = models.project_user.objects.filter(project_id=pro_id)
    print "dsfsdfsdkjfhkjsda"
    #return render_to_response('member.html', {"members": all_members})
    return render(request, 'member.html', {"members": all_members})
    pass
"""